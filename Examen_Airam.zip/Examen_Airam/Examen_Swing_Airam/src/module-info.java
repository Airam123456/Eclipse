module Examen_Swing_Airam {
	requires java.desktop;
	requires java.sql;
}