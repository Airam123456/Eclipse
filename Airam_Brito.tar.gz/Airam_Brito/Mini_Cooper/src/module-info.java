module Mini_Cooper {
	requires java.desktop;
}