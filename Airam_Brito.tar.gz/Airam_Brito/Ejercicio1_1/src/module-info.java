module ejercicio1_1 {
	requires java.desktop;
}